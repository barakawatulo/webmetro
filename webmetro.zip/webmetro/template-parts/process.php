<section id="process">
    <div class="proc-wrap">
        <div class="proc-l rv">
            <div class="eyebrow"><?php esc_html_e( 'How We Work', 'webmetro' ); ?></div>
            <h2 class="stitle">
                <?php esc_html_e( 'Our Proven', 'webmetro' ); ?><br>
                <span style="color:#00C853"><?php esc_html_e( 'Process.', 'webmetro' ); ?></span>
            </h2>
            <p class="ssub"><?php esc_html_e( 'A clear, structured approach that turns your idea into a live product — on time, on brand, on budget.', 'webmetro' ); ?></p>
        </div>
        <div>
            <?php
            $steps = [
                [ 'fa-search',      __( 'Discovery',      'webmetro' ), __( 'We deep-dive into your business goals, target audience, and competitive landscape to build the right strategy from day one — not after costly rework.', 'webmetro' ) ],
                [ 'fa-pencil-ruler',__( 'Design',         'webmetro' ), __( 'We craft wireframes and high-fidelity designs balancing beauty, usability, and your brand. We don\'t build until you love what you see.', 'webmetro' ) ],
                [ 'fa-cog',         __( 'Build',          'webmetro' ), __( 'Our developers write clean, scalable code. Every feature reviewed, every screen tested on real Kenyan networks before it ships.', 'webmetro' ) ],
                [ 'fa-rocket',      __( 'Launch & Grow',  'webmetro' ), __( 'We deploy your product, monitor performance, and continuously optimize — the relationship begins at launch, it doesn\'t end there.', 'webmetro' ) ],
            ];
            foreach ( $steps as $i => [$icon, $title, $desc] ) :
            ?>
            <div class="pstep rv" style="transition-delay:<?php echo $i * 0.15; ?>s">
                <div class="pstep-l">
                    <div class="pnum"><?php echo str_pad( $i + 1, 2, '0', STR_PAD_LEFT ); ?></div>
                    <div class="pico"><i class="fas <?php echo esc_attr( $icon ); ?>"></i></div>
                </div>
                <div>
                    <h3><?php echo esc_html( $title ); ?></h3>
                    <p><?php echo esc_html( $desc ); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
