<section id="testi">
    <div class="testi-hdr">
        <div>
            <div class="eyebrow rv"><?php esc_html_e( 'Client Stories', 'webmetro' ); ?></div>
            <h2 class="stitle rv">
                <?php esc_html_e( 'What Nairobi', 'webmetro' ); ?><br>
                <span style="color:#00C853"><?php esc_html_e( 'Says.', 'webmetro' ); ?></span>
            </h2>
        </div>
        <p class="ssub rv">
            <?php esc_html_e( 'Real results from real Kenyan businesses who decided to go digital and never looked back.', 'webmetro' ); ?>
        </p>
    </div>

    <?php $testimonials = webmetro_get_testimonials(); ?>

    <div class="tt-outer">
        <div class="tt" id="tt">
            <?php
            // Use CPT testimonials if available, else fallback
            if ( $testimonials ) :
                // Double for infinite scroll
                $all_testi = array_merge( $testimonials, $testimonials );
                foreach ( $all_testi as $t ) :
                    $company = get_post_meta( $t->ID, '_wm_company', true );
                    $rating  = get_post_meta( $t->ID, '_wm_rating',  true ) ?: 5;
                    $color   = get_post_meta( $t->ID, '_wm_color',   true ) ?: '#00C853';
                    $name    = get_the_title( $t );
                    $initials = implode( '', array_map( fn($w) => strtoupper($w[0]), explode(' ', $name) ) );
            ?>
            <div class="tcard">
                <?php echo webmetro_stars( (int) $rating ); ?>
                <p class="tq"><?php echo wp_kses_post( get_the_content( null, false, $t ) ?: get_the_excerpt( $t ) ); ?></p>
                <div class="tauth">
                    <div class="tav" style="background:<?php echo esc_attr( $color ); ?>"><?php echo esc_html( $initials ); ?></div>
                    <div>
                        <div class="tnm"><?php echo esc_html( $name ); ?></div>
                        <div class="tco"><?php echo esc_html( $company ); ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach;
            else :
                // Fallback data
                $fallback = [
                    [ 'Wanjiku Kariuki', 'Mama\'s Kitchen, Nairobi',   '#00C853', 'Web Metro transformed our online presence. Our sales went up 40% in three months.', 5 ],
                    [ 'Brian Otieno',    'SwiftRide Logistics',         '#1A73E8', 'The app they built is seamless — our drivers and customers both love it. Fast, no bugs, great support.', 5 ],
                    [ 'Amina Hassan',    'Halisi Fashion House',        '#FF6D00', 'Finally, an agency that doesn\'t treat Africa as an afterthought. Their M-Pesa integrations work perfectly.', 5 ],
                    [ 'James Mwangi',    'Savannah Real Estate',        '#E53935', 'Our Google ranking went from page 5 to page 1 in 90 days. The ROI has been incredible.', 5 ],
                    [ 'Grace Njeri',     'Bora Hardware Ltd',           '#00C853', 'KuzaERP changed how we run our business. Inventory, payroll, sales — all in one place.', 5 ],
                    [ 'Samuel Kipchoge', 'Alpine Coffee Roasters',      '#1A73E8', 'Professional team, honest pricing, they deliver on time. Genuinely rare to find in Nairobi.', 5 ],
                ];
                $all = array_merge( $fallback, $fallback );
                foreach ( $all as [$name, $company, $color, $quote, $rating] ) :
                    $initials = implode( '', array_map( fn($w) => strtoupper($w[0]), explode(' ', $name) ) );
            ?>
            <div class="tcard">
                <?php echo webmetro_stars( $rating ); ?>
                <p class="tq"><?php echo esc_html( $quote ); ?></p>
                <div class="tauth">
                    <div class="tav" style="background:<?php echo esc_attr( $color ); ?>"><?php echo esc_html( $initials ); ?></div>
                    <div>
                        <div class="tnm"><?php echo esc_html( $name ); ?></div>
                        <div class="tco"><?php echo esc_html( $company ); ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach;
            endif; ?>
        </div>
    </div>
</section>
