<section id="services">
    <div class="svc-hdr">
        <div>
            <div class="eyebrow rv"><?php esc_html_e( 'What We Do', 'webmetro' ); ?></div>
            <h2 class="stitle rv">
                <?php esc_html_e( 'We Build What', 'webmetro' ); ?><br>
                <?php esc_html_e( 'Moves Your', 'webmetro' ); ?><br>
                <span style="color:#00C853"><?php esc_html_e( 'Business.', 'webmetro' ); ?></span>
            </h2>
        </div>
        <p class="ssub rv" style="align-self:flex-end">
            <?php esc_html_e( 'From your first website to a full digital ecosystem — technology built with the African market at its core.', 'webmetro' ); ?>
        </p>
    </div>

    <?php $services = webmetro_get_services(); ?>

    <?php if ( $services ) : ?>
    <div class="svc-grid">
        <?php foreach ( $services as $i => $service ) :
            $icon  = get_post_meta( $service->ID, '_wm_icon',       true ) ?: 'fa-star';
            $stack = get_post_meta( $service->ID, '_wm_tech_stack', true );
            $tags  = $stack ? array_map( 'trim', explode( ',', $stack ) ) : [];
            $num   = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
        ?>
        <div class="scard rv" style="transition-delay:<?php echo $i * 0.15; ?>s">
            <span class="scard-n"><?php echo esc_html( $num ); ?></span>
            <div class="sicon"><i class="fas <?php echo esc_attr( $icon ); ?>"></i></div>
            <h3><?php echo esc_html( get_the_title( $service ) ); ?></h3>
            <p><?php echo wp_kses_post( get_the_excerpt( $service ) ); ?></p>
            <?php if ( $tags ) : ?>
            <div class="stags">
                <?php foreach ( $tags as $tag ) : ?>
                <span class="stag"><?php echo esc_html( $tag ); ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <a class="slink" href="#contact">
                <?php esc_html_e( 'Get Started', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else : ?>
    <!-- Fallback if no services added yet -->
    <div class="svc-grid">
        <?php
        $defaults = [
            [ 'fa-code',      'Web Development',   'Fast, beautiful websites and web apps that turn visitors into customers.', 'React,Next.js,Laravel,WordPress' ],
            [ 'fa-mobile-alt','App Development',   'Native-quality apps designed for Kenyan users and African networks.',      'Flutter,React Native,Android,iOS' ],
            [ 'fa-chart-line','Digital Marketing', 'SEO, social media, Google Ads and content that grows your visibility.',   'SEO,Google Ads,Social Media,Content' ],
        ];
        foreach ( $defaults as $i => [$icon, $title, $desc, $stack] ) :
            $tags = explode( ',', $stack );
        ?>
        <div class="scard rv" style="transition-delay:<?php echo $i * 0.15; ?>s">
            <span class="scard-n"><?php echo str_pad( $i + 1, 2, '0', STR_PAD_LEFT ); ?></span>
            <div class="sicon"><i class="fas <?php echo $icon; ?>"></i></div>
            <h3><?php echo $title; ?></h3>
            <p><?php echo $desc; ?></p>
            <div class="stags">
                <?php foreach ( $tags as $tag ) echo '<span class="stag">' . $tag . '</span>'; ?>
            </div>
            <a class="slink" href="#contact"><?php esc_html_e( 'Get Started', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i></a>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>
