<div id="stats" style="padding:0 6vw">
    <div class="stats-row">
        <?php
        for ( $i = 1; $i <= 4; $i++ ) :
            $number = wm_option( "stat{$i}_number", [ 1 => '50+', 2 => '5+', 3 => '3', 4 => '98%' ][ $i ] );
            $label  = wm_option( "stat{$i}_label",  [ 1 => 'Projects Delivered', 2 => 'Years in Business', 3 => 'Core Services', 4 => 'Client Satisfaction' ][ $i ] );
            // Strip suffix to get raw number for counter animation
            $raw    = preg_replace( '/[^0-9]/', '', $number );
            $suffix = preg_replace( '/[0-9]/', '', $number );
        ?>
        <div class="sc rv" style="transition-delay:<?php echo ( $i - 1 ) * 0.1; ?>s">
            <span class="sn" data-t="<?php echo esc_attr( $raw ); ?>" data-suffix="<?php echo esc_attr( $suffix ); ?>">
                <?php echo esc_html( $number ); ?>
            </span>
            <span class="sl"><?php echo esc_html( $label ); ?></span>
        </div>
        <?php endfor; ?>
    </div>
</div>
