<section id="blog">
    <div class="blog-hdr">
        <div>
            <div class="eyebrow rv"><?php esc_html_e( 'Insights', 'webmetro' ); ?></div>
            <h2 class="stitle rv" style="margin-bottom:0">
                <?php esc_html_e( 'Digital Insights', 'webmetro' ); ?><br>
                <span style="color:#1A73E8"><?php esc_html_e( 'from Nairobi.', 'webmetro' ); ?></span>
            </h2>
        </div>
        <a class="btn-bdr rv" href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>">
            <?php esc_html_e( 'View All Posts', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i>
        </a>
    </div>

    <?php
    $posts = get_posts( [
        'posts_per_page' => 3,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ] );
    ?>

    <div class="blog-grid">
        <?php if ( $posts ) :
            foreach ( $posts as $i => $post ) :
                $cats     = get_the_category( $post->ID );
                $cat_name = $cats ? $cats[0]->name : __( 'Insights', 'webmetro' );
                $emojis   = [ '🌐', '📲', '📊', '💡', '🚀', '📱' ];
                $emoji    = $emojis[ $i % count($emojis) ];
                $bgs      = [
                    'linear-gradient(135deg,#e8f0fe,#ccd8fc)',
                    'linear-gradient(135deg,#e4f8ee,#c2ecd4)',
                    'linear-gradient(135deg,#fef8e8,#fce8b8)',
                ];
        ?>
        <div class="bcard rv" style="transition-delay:<?php echo $i * 0.1; ?>s">
            <?php if ( has_post_thumbnail( $post->ID ) ) : ?>
                <div class="bthumb" style="background:#f0f0ee;overflow:hidden;padding:0">
                    <?php echo get_the_post_thumbnail( $post->ID, 'webmetro-blog', [ 'style' => 'width:100%;height:100%;object-fit:cover' ] ); ?>
                </div>
            <?php else : ?>
                <div class="bthumb" style="background:<?php echo $bgs[$i % 3]; ?>"><?php echo $emoji; ?></div>
            <?php endif; ?>
            <div class="bcontent">
                <div class="bcat"><?php echo esc_html( $cat_name ); ?></div>
                <h3><?php echo esc_html( get_the_title( $post ) ); ?></h3>
                <div class="bmeta">
                    <span><?php echo get_the_date( 'M j, Y', $post ); ?></span>
                    <a class="rm" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
                        <?php esc_html_e( 'Read', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach;
        else :
            // Fallback preview cards
            $previews = [
                [ '#1A73E8', '🌐', 'Web Trends',        'Why Every Kenyan SME Needs a Mobile-First Website in 2025',         'Mar 12, 2025' ],
                [ '#00C853', '📲', 'App Development',   'Flutter vs React Native: Which Should You Choose for Your African App?', 'Feb 28, 2025' ],
                [ '#FF6D00', '📊', 'Digital Marketing', 'How Nairobi Startups Are Winning with Google Ads on a Tight Budget', 'Feb 14, 2025' ],
            ];
            $bgs = [ 'linear-gradient(135deg,#e8f0fe,#ccd8fc)', 'linear-gradient(135deg,#e4f8ee,#c2ecd4)', 'linear-gradient(135deg,#fef8e8,#fce8b8)' ];
            foreach ( $previews as $i => [$color, $emoji, $cat, $title, $date] ) :
        ?>
        <div class="bcard rv" style="transition-delay:<?php echo $i * 0.1; ?>s">
            <div class="bthumb" style="background:<?php echo $bgs[$i]; ?>"><?php echo $emoji; ?></div>
            <div class="bcontent">
                <div class="bcat" style="color:<?php echo $color; ?>"><?php echo esc_html( $cat ); ?></div>
                <h3><?php echo esc_html( $title ); ?></h3>
                <div class="bmeta">
                    <span><?php echo esc_html( $date ); ?></span>
                    <a class="rm" href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>">
                        <?php esc_html_e( 'Read', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach;
        endif; ?>
    </div>
</section>
