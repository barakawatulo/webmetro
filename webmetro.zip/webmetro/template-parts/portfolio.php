<section id="portfolio">
    <div class="port-hdr">
        <div>
            <div class="eyebrow rv"><?php esc_html_e( 'Selected Work', 'webmetro' ); ?></div>
            <h2 class="stitle rv" style="margin-bottom:0">
                <?php esc_html_e( 'Our', 'webmetro' ); ?><br>
                <span style="color:#00C853"><?php esc_html_e( 'Projects.', 'webmetro' ); ?></span>
            </h2>
        </div>

        <!-- Portfolio Filter Tabs (categories) -->
        <div class="ftabs">
            <button class="ftab on" data-f="all"><?php esc_html_e( 'All', 'webmetro' ); ?></button>
            <?php
            $cats = get_terms( [ 'taxonomy' => 'wm_portfolio_cat', 'hide_empty' => true ] );
            foreach ( $cats as $cat ) :
            ?>
            <button class="ftab" data-f="<?php echo esc_attr( $cat->slug ); ?>">
                <?php echo esc_html( $cat->name ); ?>
            </button>
            <?php endforeach; ?>
        </div>
    </div>

    <?php $projects = webmetro_get_portfolio( 6 ); ?>

    <div class="port-grid" id="pgrid">
        <?php if ( $projects ) :
            foreach ( $projects as $i => $project ) :
                $client  = get_post_meta( $project->ID, '_wm_client',  true );
                $url     = get_post_meta( $project->ID, '_wm_url',     true );
                $emoji   = get_post_meta( $project->ID, '_wm_emoji',   true ) ?: '🌐';
                $bgcolor = get_post_meta( $project->ID, '_wm_bgcolor', true ) ?: 'linear-gradient(135deg,#e4f4ed,#c2e8d4)';
                $cats    = get_the_terms( $project->ID, 'wm_portfolio_cat' );
                $cat_slugs = $cats ? implode( ' ', wp_list_pluck( $cats, 'slug' ) ) : '';
        ?>
        <div class="pi rv" data-c="<?php echo esc_attr( $cat_slugs ); ?>" style="transition-delay:<?php echo $i * 0.06; ?>s">
            <div class="pi-in">
                <?php if ( has_post_thumbnail( $project->ID ) ) : ?>
                    <div class="pi-bg" style="background:#f0f0ee">
                        <?php echo get_the_post_thumbnail( $project->ID, 'webmetro-portfolio', [ 'style' => 'width:100%;height:100%;object-fit:cover;position:absolute;inset:0' ] ); ?>
                    </div>
                <?php else : ?>
                    <div class="pi-bg" style="background:<?php echo esc_attr( $bgcolor ); ?>">
                        <?php echo esc_html( $emoji ); ?>
                    </div>
                <?php endif; ?>
                <div class="pi-ov">
                    <?php if ( $cats ) : ?>
                    <div class="pi-tags">
                        <?php foreach ( $cats as $cat ) : ?>
                        <span class="pitag"><?php echo esc_html( $cat->name ); ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <div class="pi-nm"><?php echo esc_html( get_the_title( $project ) ); ?></div>
                    <?php if ( $client ) : ?>
                    <div class="pi-cl"><?php echo esc_html( $client ); ?></div>
                    <?php endif; ?>
                    <a class="pi-lk" href="<?php echo $url ? esc_url( $url ) : '#contact'; ?>"
                       <?php echo $url ? 'target="_blank" rel="noopener"' : ''; ?>>
                        <?php esc_html_e( 'View Project', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach;
        else :
            // Fallback placeholder projects
            $placeholders = [
                [ '🛒', 'linear-gradient(135deg,#e4f4ed,#c2e8d4)', 'ShopKenya Online',   'Nairobi Retail Group',  'web', 'E-Commerce,Web Dev'    ],
                [ '📱', 'linear-gradient(135deg,#e8effe,#ccd8fc)', 'PesaTrack App',      'FinAccess Kenya',       'app', 'Mobile App,Fintech'    ],
                [ '📈', 'linear-gradient(135deg,#fef7e4,#fde8a8)', 'Safari Ranking',     'Savannah Tours Ltd',    'marketing', 'SEO,Google Ads' ],
                [ '🏥', 'linear-gradient(135deg,#f0e8fc,#d8c2f4)', 'AfyaConnect Portal', 'Mater Hospital Group',  'web', 'Web Dev,Healthcare'   ],
                [ '🚚', 'linear-gradient(135deg,#e4f0fc,#b8d8f4)', 'BodaBoda Fleet',     'Sendy Logistics',       'app', 'Mobile App,Logistics'  ],
                [ '🎯', 'linear-gradient(135deg,#fde8e8,#f8c0c0)', 'Brand Launch NBO',   'Kali Foods Kenya',      'marketing', 'Social,Content'  ],
            ];
            foreach ( $placeholders as $i => [$emoji, $bg, $name, $client, $cat, $tags] ) :
                $tag_list = explode( ',', $tags );
        ?>
        <div class="pi rv" data-c="<?php echo esc_attr( $cat ); ?>" style="transition-delay:<?php echo $i * 0.06; ?>s">
            <div class="pi-in">
                <div class="pi-bg" style="background:<?php echo $bg; ?>"><?php echo $emoji; ?></div>
                <div class="pi-ov">
                    <div class="pi-tags">
                        <?php foreach ( $tag_list as $tag ) echo '<span class="pitag">' . esc_html( trim($tag) ) . '</span>'; ?>
                    </div>
                    <div class="pi-nm"><?php echo esc_html( $name ); ?></div>
                    <div class="pi-cl"><?php echo esc_html( $client ); ?></div>
                    <a class="pi-lk" href="#contact"><?php esc_html_e( 'View Project', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
        <?php endforeach;
        endif; ?>
    </div>

    <div class="port-cta">
        <a class="btn-bdr" href="<?php echo esc_url( get_post_type_archive_link( 'wm_portfolio' ) ); ?>">
            <?php esc_html_e( 'View All Projects', 'webmetro' ); ?> <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</section>
