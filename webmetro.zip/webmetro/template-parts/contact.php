<section id="contact">
    <div class="contact-wrap">
        <div class="rvl">
            <div class="ci-eye"><?php esc_html_e( 'Let\'s Talk', 'webmetro' ); ?></div>
            <h2 class="ctitle">
                <?php esc_html_e( 'Ready to Go', 'webmetro' ); ?><br>
                <span><?php esc_html_e( 'Digital?', 'webmetro' ); ?></span>
            </h2>
            <p class="ci-desc">
                <?php esc_html_e( 'Tell us about your project. Our team will get back to you within 24 hours with a clear plan forward.', 'webmetro' ); ?>
            </p>

            <div class="cdets">
                <?php $address = wm_option( 'contact_address', 'Nairobi, Kenya' ); ?>
                <div class="cdi">
                    <div class="cdi-ic"><i class="fas fa-map-marker-alt"></i></div>
                    <span><?php echo esc_html( $address ); ?></span>
                </div>
                <?php $email = wm_option( 'contact_email', 'info@webmetro.co.ke' ); ?>
                <div class="cdi">
                    <div class="cdi-ic"><i class="fas fa-envelope"></i></div>
                    <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
                </div>
                <?php $phone = wm_option( 'contact_phone', '+254 700 000 000' ); ?>
                <div class="cdi">
                    <div class="cdi-ic"><i class="fas fa-phone"></i></div>
                    <a href="tel:<?php echo esc_attr( preg_replace('/\s+/', '', $phone) ); ?>"><?php echo esc_html( $phone ); ?></a>
                </div>
            </div>

            <?php $wa = wm_option( 'contact_whatsapp', '254700000000' ); ?>
            <a class="wa-btn" href="https://wa.me/<?php echo esc_attr( $wa ); ?>" target="_blank" rel="noopener">
                <i class="fab fa-whatsapp" style="font-size:1.2rem"></i>
                <?php esc_html_e( 'Chat on WhatsApp', 'webmetro' ); ?>
            </a>

            <div class="socials">
                <?php
                $networks = [ 'linkedin' => 'fab fa-linkedin-in', 'twitter' => 'fab fa-x-twitter', 'instagram' => 'fab fa-instagram', 'facebook' => 'fab fa-facebook-f' ];
                foreach ( $networks as $network => $icon ) :
                    $url = wm_option( "social_{$network}", '#' );
                ?>
                <a class="soc" href="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( ucfirst($network) ); ?>" target="_blank" rel="noopener">
                    <i class="<?php echo esc_attr( $icon ); ?>"></i>
                </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="rvr">
            <div class="cform">
                <div id="fw">
                    <div class="form-row">
                        <div class="fg">
                            <label for="wm_name"><?php esc_html_e( 'Name', 'webmetro' ); ?></label>
                            <input type="text" id="wm_name" name="wm_name" placeholder="John Kamau" required>
                        </div>
                        <div class="fg">
                            <label for="wm_email"><?php esc_html_e( 'Email', 'webmetro' ); ?></label>
                            <input type="email" id="wm_email" name="wm_email" placeholder="john@company.co.ke" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="fg">
                            <label for="wm_phone"><?php esc_html_e( 'Phone / WhatsApp', 'webmetro' ); ?></label>
                            <input type="tel" id="wm_phone" name="wm_phone" placeholder="+254 7XX XXX XXX">
                        </div>
                        <div class="fg">
                            <label for="wm_service"><?php esc_html_e( 'Service Interest', 'webmetro' ); ?></label>
                            <select id="wm_service" name="wm_service">
                                <option value=""><?php esc_html_e( 'Select...', 'webmetro' ); ?></option>
                                <option><?php esc_html_e( 'Web Development',   'webmetro' ); ?></option>
                                <option><?php esc_html_e( 'App Development',   'webmetro' ); ?></option>
                                <option><?php esc_html_e( 'Digital Marketing', 'webmetro' ); ?></option>
                                <option><?php esc_html_e( 'KuzaERP',           'webmetro' ); ?></option>
                                <option><?php esc_html_e( 'Other',             'webmetro' ); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="fg">
                        <label for="wm_message"><?php esc_html_e( 'Your Project', 'webmetro' ); ?></label>
                        <textarea id="wm_message" name="wm_message" placeholder="<?php esc_attr_e( 'Tell us what you\'d like to build or achieve...', 'webmetro' ); ?>"></textarea>
                    </div>
                    <button class="btn-sub" id="wmSubmitBtn" type="button">
                        <?php esc_html_e( 'Send Message', 'webmetro' ); ?>
                        <i class="fas fa-paper-plane" style="font-size:.8rem"></i>
                    </button>
                    <p class="wm-form-error" id="wmFormError" style="color:#E53935;font-size:.85rem;margin-top:12px;display:none"></p>
                </div>
                <div class="form-ok" id="fok">
                    <i class="fas fa-check-circle"></i>
                    <h3><?php esc_html_e( 'Message Sent!', 'webmetro' ); ?></h3>
                    <p><?php esc_html_e( 'Our team will reach out within 24 hours.', 'webmetro' ); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
